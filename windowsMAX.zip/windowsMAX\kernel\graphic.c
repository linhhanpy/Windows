/* �O���t�B�b�N�����֌W */

#include "bootpack.h"
void init_palette(void)
{
	static unsigned char table_rgb[16 * 3] = {
		0x00, 0x00, 0x00,	/*  0:�K */
		0xff, 0x00, 0x00,	/*  1:��? */
		0x00, 0xff, 0x00,	/*  2:��? */
		0xff, 0xff, 0x00,	/*  3:���� */
		0x00, 0x00, 0xff,	/*  4:��? */
		0xff, 0x00, 0xff,	/*  5:���� */
		0x00, 0xff, 0xff,	/*  6:��? */
		0xff, 0xff, 0xff,	/*  7:�� */
		0xc6, 0xc6, 0xc6,	/*  8:���D */
		0x84, 0x00, 0x00,	/*  9:��? */
		0x00, 0x84, 0x00,	/* 10:��? */
		0x84, 0x84, 0x00,	/* 11:�É� */
		0x00, 0x00, 0x84,	/* 12:�Ð� */
		0x84, 0x00, 0x84,	/* 13:�Î� */
		0x00, 0x84, 0x84,	/* 14:���? */
		0x84, 0x84, 0x84	/* 15:�ÊD */
	};
	unsigned char table2[216 * 3];
	int r, g, b;
	set_palette(0, 15, table_rgb);
	for (b = 0; b < 6; b++) {
		for (g = 0; g < 6; g++) {
			for (r = 0; r < 6; r++) {
				table2[(r + g * 6 + b * 36) * 3 + 0] = r * 51;
				table2[(r + g * 6 + b * 36) * 3 + 1] = g * 51;
				table2[(r + g * 6 + b * 36) * 3 + 2] = b * 51;
			}
		}
	}
	set_palette(16, 231, table2);
	return;
}

void set_palette(int start, int end, unsigned char *rgb)
{
	int i, eflags;
	eflags = io_load_eflags();	
	io_cli(); 					
	io_out8(0x03c8, start);
	for (i = start; i <= end; i++) {
		io_out8(0x03c9, rgb[0] / 4);
		io_out8(0x03c9, rgb[1] / 4);
		io_out8(0x03c9, rgb[2] / 4);
		rgb += 3;
	}
	io_store_eflags(eflags);	
	return;
}

void boxfill8(unsigned char *vram, int xsize, unsigned char c, int x0, int y0, int x1, int y1)
{
	int x, y;
	for (y = y0; y <= y1; y++) {
		for (x = x0; x <= x1; x++)
			vram[y * xsize + x] = c;
	}
	return;
}
void init_screen8(char *vram, int x, int y)
{
int *fat;
unsigned char c;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
boxfill8(vram, x, COL8_00FFFF,  0,     0,      x -  1, y - 29);
fat = (int *) memman_alloc_4k(memman, 4 * 2880);
file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
read_picture(fat, vram, x, y);
memman_free_4k(memman, (int) fat, 4 * 2880);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
//boxfill8(vram, x, COL8_00FFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);

	putfonts8_asc(vram, x, 10, 748, COL8_FFFFFF, "Start");

return;
}
int read_picture(int *fat, char *vram, int x, int y)
{
int i, j, x0, y0, fsize, info[4];
unsigned char *filebuf, r, g, b;
struct RGB *picbuf;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
struct FILEINFO *finfo;
struct DLL_STRPICENV *env;
finfo = file_search("desktop1.jpg", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
if (finfo == 0) {
return -1;
}
fsize = finfo->size;
filebuf = (unsigned char *) memman_alloc_4k(memman, fsize);
filebuf = file_loadfile2(finfo->clustno, &fsize, fat);
env = (struct DLL_STRPICENV *) memman_alloc_4k(memman, sizeof(struct DLL_STRPICENV));
info_JPEG(env, info, fsize, filebuf);
picbuf = (struct RGB *) memman_alloc_4k(memman, info[2] * info[3] * sizeof(struct RGB));
decode0_JPEG(env, fsize, filebuf, 4, (unsigned char *) picbuf, 0);
x0 = (int) ((x - info[2]) / 2);
y0 = (int) ((y - info[3]) / 2);
for (i = 0; i < info[3]; i++) {
for (j = 0; j < info[2]; j++) {
r = picbuf[i * info[2] + j].r;
g = picbuf[i * info[2] + j].g;
b = picbuf[i * info[2] + j].b;
vram[(y0 + i) * x + (x0 + j)] = rgb2pal(r, g, b, j, i, binfo->vmode);
}
}
memman_free_4k(memman, (int) filebuf, fsize);
memman_free_4k(memman, (int) picbuf , info[2] * info[3] * sizeof(struct RGB));
memman_free_4k(memman, (int) env , sizeof(struct DLL_STRPICENV));
return 0;
}
unsigned short rgb2pal(int r, int g, int b, int x, int y, int cb)
{
if (cb == 8) {
static int table[4] = { 3, 1, 0, 2 };
int i;
x &= 1; /* ������?���?�H */
y &= 1;
i = table[x + y * 2];
r = (r * 21) / 256;
g = (g * 21) / 256;
b = (b * 21) / 256;
r = (r + i) / 4;
g = (g + i) / 4;
b = (b + i) / 4;
return((unsigned short) (16 + r + g * 6 + b * 36));
} else {
return((unsigned short) (((r << 8) & 0xf800) | ((g << 3) & 0x07e0) | (b >> 3)));
}
}
void init_screen(char *vram, int x, int y)
{
	boxfill8(vram, x, COL8_0000FF,  0,     0,      x -  1, y - 29);
	boxfill8(vram, x, COL8_00FFFF,  0,     y - 28, x -  1, y - 28);
	boxfill8(vram, x, COL8_FFFFFF,  0,     y - 27, x -  1, y - 27);
	boxfill8(vram, x, COL8_00FFFF,  0,     y - 26, x -  1, y -  1);

	boxfill8(vram, x, COL8_FFFFFF,  3,     y - 24, 59,     y - 24);
	boxfill8(vram, x, COL8_FFFFFF,  2,     y - 24,  2,     y -  4);
	boxfill8(vram, x, COL8_00FFFF,  3,     y -  4, 59,     y -  4);
	boxfill8(vram, x, COL8_00FFFF, 59,     y - 23, 59,     y -  5);
	boxfill8(vram, x, COL8_000000,  2,     y -  3, 59,     y -  3);
	boxfill8(vram, x, COL8_000000, 60,     y - 24, 60,     y -  3);

	boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x -  4, y - 24);
	boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y -  4);
	boxfill8(vram, x, COL8_FFFFFF, x - 47, y -  3, x -  4, y -  3);
	boxfill8(vram, x, COL8_FFFFFF, x -  3, y - 24, x -  3, y -  3);

	boxfill8(vram, x, COL8_0000FF,  0,     0,      1,1);
	
	putfonts8_asc(vram, x, 360, 210, COL8_FFFF00," _   _              ___  ____  ");
	putfonts8_asc(vram, x, 360, 225, COL8_FFFF00,"| | | | __ _ _ __  / _ \\/ ___| ");
	putfonts8_asc(vram, x, 360, 240, COL8_FFFF00,"| |_| |/ _` | '_ \\| | | \\___ \\ ");
	putfonts8_asc(vram, x, 360, 255, COL8_FFFF00,"|  _  | (_| | | | | |_| |___) |");
	putfonts8_asc(vram, x, 360, 270, COL8_FFFF00,"|_| |_|\\__,_|_| |_|\\___/|____/ ");
	putfonts8_asc(vram, x, 401, 401, COL8_000000, "Han Operating System.");
	putfonts8_asc(vram, x, 400, 400, COL8_FFFFFF, "Han Operating System.");
	putfonts8_asc(vram, x, 10, 748, COL8_000000, "Start");
	putfonts8_asc(vram, x, 100, 748, COL8_000000, "Running:");
	putfonts8_asc(vram, x, 180, 748, COL8_000000, "|command|");
	putfonts8_asc(vram, x, 680, 748, COL8_000000, "|Area:China");
	putfonts8_asc(vram, x, 810, 748, COL8_000000, "|");
	putfonts8_asc(vram, x, 840, 748, COL8_000000, "|^|");

	return;
}
void putfont32(char *vram, int xsize, int x, int y, char c, char *font)
{
	int i;
	char *p, d /* data */;
	for (i = 0; i < 16; i++) {               //�������f�_?�I�s���z? 
		p = vram + (y + i) * xsize + x;      //�������f�_?�I?�n�ʒu
		d = font[i * 2];//��?���I���n�n��?�N�n�C���@?��?�n���A����2
		if ((d & 0x80) != 0) { p[0] = c; }   //p��\���������f�_?��s�I��8��
		if ((d & 0x40) != 0) { p[1] = c; }
		if ((d & 0x20) != 0) { p[2] = c; }
		if ((d & 0x10) != 0) { p[3] = c; }
		if ((d & 0x08) != 0) { p[4] = c; }
		if ((d & 0x04) != 0) { p[5] = c; }
		if ((d & 0x02) != 0) { p[6] = c; }
		if ((d & 0x01) != 0) { p[7] = c; }
	}
	return;
}

void putfont8(char *vram, int xsize, int x, int y, char c, char *font)
{
	int i;
	char *p, d /* data */;
	for (i = 0; i < 16; i++) {
		p = vram + (y + i) * xsize + x;
		d = font[i];
		if ((d & 0x80) != 0) { p[0] = c; }
		if ((d & 0x40) != 0) { p[1] = c; }
		if ((d & 0x20) != 0) { p[2] = c; }
		if ((d & 0x10) != 0) { p[3] = c; }
		if ((d & 0x08) != 0) { p[4] = c; }
		if ((d & 0x04) != 0) { p[5] = c; }
		if ((d & 0x02) != 0) { p[6] = c; }
		if ((d & 0x01) != 0) { p[7] = c; }
	}
	return;
}

void putfonts8_asc(char *vram, int xsize, int x, int y, char c, unsigned char *s) //s�w��������??�I�ʒu�C�����Ȓ��ڎg�ps?�s?�掚�����I?�꘢?�Ǝ����G ��ascii??
{
	extern char hankaku[4096];
	struct TASK *task = task_now();
	char *nihongo = (char *) *((int *) 0x0fe8), *font;
	char *hzk = (char *) *((int *) 0x0fe8);
	int k, t;

	if (task->langmode == 0) {//��?�I�����W
		for (; *s != 0x00; s++) {
			putfont8(vram, xsize, x, y, c, hankaku + *s * 16);
			x += 8;
		}
	}
	if (task->langmode == 1) {//shift jis ���I����?��
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if ((0x81 <= *s && *s <= 0x9f) || (0xe0 <= *s && *s <= 0xfc)) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, nihongo + *s * 16);
				}
			} else {
				if (0x81 <= task->langbyte1 && task->langbyte1 <= 0x9f) {
					k = (task->langbyte1 - 0x81) * 2;
				} else {
					k = (task->langbyte1 - 0xe0) * 2 + 62;
				}
				if (0x40 <= *s && *s <= 0x7e) {
					t = *s - 0x40;
				} else if (0x80 <= *s && *s <= 0x9e) {
					t = *s - 0x80 + 63;
				} else {
					t = *s - 0x9f;
					k++;
				}
				task->langbyte1 = 0;
				font = nihongo + 256 * 16 + (k * 94 + t) * 32;
				putfont8(vram, xsize, x - 8, y, c, font     );	/* ������ */
				putfont8(vram, xsize, x    , y, c, font + 16);	/* �E���� */
			}
			x += 8;
		}
	}
		if (task->langmode == 2) {//EUC �͎����I����
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if (0x81 <= *s && *s <= 0xfe) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, nihongo + *s * 16);
				}
			} else {
				k = task->langbyte1 - 0xa1;
				t = *s - 0xa1;
				task->langbyte1 = 0;
				font = nihongo + 256 * 16 + (k * 94 + t) * 32;
				putfont8(vram, xsize, x - 8, y, c, font     );	/* ������ */
				putfont8(vram, xsize, x    , y, c, font + 16);	/* �E���� */
			}
			x += 8;
		}
	}
	if (task->langmode == 3) {//GB2312 HKZ16 �����͎�
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if (0xa1 <= *s && *s <= 0xfe) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, hankaku + *s * 16);
				}
			} else {
				k = task->langbyte1 - 0xa1;
				t = *s - 0xa1;
				task->langbyte1 = 0;
				font = hzk + (k * 94 + t) * 32;
				putfont32(vram, xsize, x - 8, y, c, font   );	/* ������ */
				putfont32(vram, xsize, x    , y, c, font + 1 );	/* �E���� */
			}
			x += 8;
		}
	}
	return;
}

void init_mouse_cursor8(char *mouse, char bc)
/* �}�E�X�J�[�\���������i16x16�j */
{
	static char cursor[16][16] = {
	 "**..............",
	 "*O*.............",
	 "*OO*............",
	 "*OOO*...........",
	 "*OOOO*..........",
	 "*OOOOO*.........",
	 "*OOOOOO*........",
	 "*OOOOOOO*.......",
	 "*OOOOOOOO*......",
	 "*OOOOOOOOO*.....",
	 "*OOOOOO*****....",
	 "*OO**OO*........",
	 "*O*.*OO*........",
	 "**...*OO*.......",
	 "*....*OO*.......",
	 "......**........"

	};
	int x, y;

	for (y = 0; y < 16; y++) {
		for (x = 0; x < 16; x++) {
			if (cursor[y][x] == '*') {
				mouse[y * 16 + x] = COL8_000000;
			}
			if (cursor[y][x] == 'O') {
				mouse[y * 16 + x] = COL8_FFFFFF;
			}
			if (cursor[y][x] == '.') {
				mouse[y * 16 + x] = bc;
			}
		}
	}
	return;
}

void init_cmd(char *mouse)
{
	static char cursor[16][16] = {
	 "................",
	 "................",
	 "...*............",
	 "....*...........",
	 ".....*..........",
	 "......*.........",
	 ".......*........",
	 "........*.......",
	 ".......*........",
	 "......*.........",
	 ".....*..........",
	 "....*...........",
	 "...*............",
	 "................",
	 "......*********.",
	 "................",


	};
	int x, y;

	for (y = 0; y < 16; y++) {
		for (x = 0; x < 16; x++) {
			if (cursor[y][x] == '*') {
				mouse[y * 16 + x] = COL8_FFFFFF;
			}
			if (cursor[y][x] == 'O') {
				mouse[y * 16 + x] = COL8_FFFFFF;
			}
			if (cursor[y][x] == '.') {
				mouse[y * 16 + x] = COL8_000000;
			}
		}
	}
	return;
}
void init_s1(char *mouse)
{
	static char cursor[16][16] = {
	 ".....*....*.....",
	 ".....*....*.....",
	 "...**********...",
	 ".....*....*.....",
	 ".....*..*.*.....",
	 "........*.......",
	 "....********....",
	 "....*...*..*....",
	 "....*...*..*..*.",
	 ".***************",
	 ".......**.......",
	 "......*..*......",
	 ".....*....*.....",
	 "....*......*....",
	 "..**.......***..",
	 "................",


	};
	int x, y;

	for (y = 0; y < 16; y++) {
		for (x = 0; x < 16; x++) {
			if (cursor[y][x] == '*') {
				mouse[y * 16 + x] = COL8_000000;
			}
			if (cursor[y][x] == 'O') {
				mouse[y * 16 + x] = COL8_FFFFFF;
			}
			if (cursor[y][x] == '.') {
				mouse[y * 16 + x] = COL8_848484;
			}
		}
	}
	return;
}
void init_china(char *resultArray)
{
    static char cursor[20][35] = {
        "...................................",
        "..............**...................",
        "......*.......***..................",
        ".....***.......*...................",
        "..*********.......*................",
        "....*****........***...............",
        "....**.**........*.*...............",
        "...*.....*....**...................",
        "..............***..................",
        "...........*...*...................",
        "..........***......................",
        "..........**.......................",
        "...................................",
        "...................................",
        "...................................",
        "...................................",
        "...................................",
        "...................................",
        "...................................",
        "...................................",
    };
    int x, y;

    for (y = 0; y < 20; y++) {
        for (x = 0; x < 35; x++) {
            if (cursor[y][x] == '*') {
                resultArray[y * 35 + x] = COL8_FFFF00;
            }
            if (cursor[y][x] == '.') {
                resultArray[y * 35 + x] = COL8_FF0000;
            }
        }
    }
    return;
}

void putblock8_8(char *vram, int vxsize, int pxsize,
	int pysize, int px0, int py0, char *buf, int bxsize)
{
	int x, y;
	for (y = 0; y < pysize; y++) {
		for (x = 0; x < pxsize; x++) {
			vram[(py0 + y) * vxsize + (px0 + x)] = buf[y * bxsize + x];
		}
	}
	return;
}
void putfonts_asc(char *vram, int xsize, int x, int y, char c, unsigned char *s)
{
	extern char hankaku[4096];
	for (; *s != 0x00; s++) {
		putfont8(vram, xsize, x, y, c, hankaku + *s * 16);
		x += 8;
	}
	return;

}
void font_init(unsigned char mode)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	int *fat;
	int i;
	unsigned char *nihongo, *hzk;
	struct FILEINFO *finfo;
	extern char hankaku[4096];
    if( mode == 3)
	{
		//?��HZK16,���������W
		hzk = (unsigned char *) memman_alloc_4k(memman, 0x5d5d * 32);
		fat = (int *) memman_alloc_4k(memman, 4 * 2880);
		file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
		finfo = file_search("HZK16.fnt", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
		if (finfo != 0) {
		file_loadfile(finfo->clustno, finfo->size, hzk, fat, (char *) (ADR_DISKIMG + 0x003e00));
		} else {
			for (i = 0; i < 16 * 256; i++) {
			hzk[i] = hankaku[i]; /* �v�L����?�C?����??�O�ʓI�p������? */
			}
			for (i = 16 * 256; i < 0x5d5d * 32; i++) {
			hzk[i] = 0xff; /* ���������U�[0xff*/
			}
		}
		*((int *) 0x0fe8) = (int) hzk; //�p0xfe8����?�n��
		memman_free_4k(memman, (int) fat, 4 * 2880);
	}

	if( mode == 2)
	{
		nihongo = (unsigned char *) memman_alloc_4k(memman, 16 * 256 + 32 * 94 * 47);
		fat = (int *) memman_alloc_4k(memman, 4 * 2880);
		file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
		finfo = file_search("nihongo.fnt", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
		if (finfo != 0) {
			file_loadfile(finfo->clustno, finfo->size, nihongo, fat, (char *) (ADR_DISKIMG + 0x003e00));
		} else {
			for (i = 0; i < 16 * 256; i++) {
				nihongo[i] = hankaku[i]; /* �v�L����?�C?����??�O�ʓI�p������? */
			}
			for (i = 16 * 256; i < 16 * 256 + 32 * 94 * 47; i++) {
				nihongo[i] = 0xff; /* ���������U�[0xff*/
			}
		}
		*((int *) 0x0fd8) = (int) nihongo; //�p0xfe8����?�n��
		memman_free_4k(memman, (int) fat, 4 * 2880);
	}
}
